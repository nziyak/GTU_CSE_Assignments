#include <iostream>
#include <sstream>
#include <string>
#include <cstdlib>

#include "SchoolManagerSystem.h"

using namespace std;
using namespace PA3;

int main()
{
    SchoolManagementSystem system1;

    system1.menu();

    return 0;
}